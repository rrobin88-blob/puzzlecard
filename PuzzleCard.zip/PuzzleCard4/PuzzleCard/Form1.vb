﻿Option Explicit On
Option Strict Off

Imports System.ComponentModel
Imports System.IO

Public Class Form1

    Const strFormTitle As String = ("PuzzleCard4 - Word Search Maker")

    Dim arrWords() As String

    Dim lngRnd As Long = 0

    Dim intLen As Integer = 0
    Dim strFormTag As String

    Dim cmdLine As String = ("")

    Dim sFileText As String = ("")
    Dim iFileNo As Integer = 0

    Public strWordlist As String = ("")

    Dim boolFontBold As Boolean = False

    Dim arrPuzzleSplit() As String

    Dim lngPuzzleCreation As Long = 0
    Dim lngPuzzleNumber As Long = 0
    Dim lngPuzzleWords As Long = 0
    Dim strPuzzleMatrix As String = ("")
    Dim intSleep As Integer = 0
    Dim intchkHidePuzzle As Integer = 0
    Dim lngPuzzleWordbank As Long = 0

    Dim strAppPath As String = ("")
    Dim strAppDocPath As String = ("")

    Dim lngDoLoopTick As Long = 0
    Dim lngMTick As Long = 0

    Dim boolFlag1 As Boolean = False

    Dim boolOnePuzzle As Boolean = False

    Dim lngFolderTick As Long = 0

    Private Sub PuzzleCard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error GoTo ErrHld

        cmdLine = Command$()

        Me.Text = (strFormTitle$)

        intIcon = 3
        intLen = 107

        lngRnd& = 9223372036854775807

        txtWordsearcheCreation.Text = ("83010348331692982263")
        txtWordsearches.Text = ("83010348331692982263")
        txtAmount.Text = ("25")
        cmbMatrixSize.Text = ("26x26")

        Call cmbMatrixSize.Items.Add("10x10")
        Call cmbMatrixSize.Items.Add("15x15")
        Call cmbMatrixSize.Items.Add("20x20")
        Call cmbMatrixSize.Items.Add("23x23")
        Call cmbMatrixSize.Items.Add("26x26")
        Call cmbMatrixSize.Items.Add("30x20")
        Call cmbMatrixSize.Items.Add("30x30")
        Call cmbMatrixSize.Items.Add("31x31")
        Call cmbMatrixSize.Items.Add("32x32")
        Call cmbMatrixSize.Items.Add("33x33")
        Call cmbMatrixSize.Items.Add("40x40")
        Call cmbMatrixSize.Items.Add("50x50")
        Call cmbMatrixSize.Items.Add("56x88")
        Call cmbMatrixSize.Items.Add("60x60")
        Call cmbMatrixSize.Items.Add("70x70")

        Call cmbResData.Items.Add("100")
        Call cmbResData.Items.Add("101")
        Call cmbResData.Items.Add("102")
        Call cmbResData.Items.Add("103")
        Call cmbResData.Items.Add("104")
        Call cmbResData.Items.Add("105")
        Call cmbResData.Items.Add("106")
        Call cmbResData.Items.Add("107")
        Call cmbResData.Items.Add("108")
        Call cmbResData.Items.Add("109")
        Call cmbResData.Items.Add("110")
        Call cmbResData.Items.Add("111")
        Call cmbResData.Items.Add("112")
        Call cmbResData.Items.Add("113")
        Call cmbResData.Items.Add("114")
        Call cmbResData.Items.Add("115")
        Call cmbResData.Items.Add("116")

        cmbResData.SelectedItem = "100"

        txtSleep.Text = "5"
        txtFontSize.Text = "12"

        strAppPath$ = Application.StartupPath()
        strAppDocPath$ = Mid(CurDir$(), 1, 1) & ":" & Environ("HOMEPATH")

        Dim i As Integer
        Dim z As Integer

        'TimLoadWordbank.Enabled = True

        rtfWords.Enabled = False

        Dim appPath As String = Application.StartupPath()

        'Dim reader As IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(appPath$ & "\wordbank0.txt")
        'Dim a As String

        'Do
        'Application.DoEvents()
        'a$ = reader.ReadLine
        'txtWords.Text &= a$.Trim & vbCrLf
        'application.DoEvents()
        'Loop Until a Is Nothing

        'Call reader.Close()

        If (File.Exists(appPath$ & "\wordbank.txt") = True) Then

            Call rtfWords.LoadFile(appPath$ & "\wordbank.txt", RichTextBoxStreamType.PlainText)

        End If

        ReDim arrWords(0)

        arrWords = Split(rtfWords.Text, vbLf, -1)

        rtfWords.Enabled = True

        Call Randomize()

        Dim v(25) As VariantType

        v(0) = 368
        v(1) = 65
        v(2) = 124
        v(3) = 171
        v(4) = 591
        v(5) = 132
        v(6) = 90
        v(7) = 237
        v(8) = 286
        v(9) = 6
        v(10) = 19
        v(11) = 153
        v(12) = 114
        v(13) = 320
        v(14) = 360
        v(15) = 89
        v(16) = 5
        v(17) = 308
        v(18) = 275
        v(19) = 473
        v(20) = 111
        v(21) = 41
        v(22) = 68
        v(23) = 7
        v(24) = 89
        v(25) = 3

        For i = 0 To 25
            lngW(i) = v(i)
            lngSumW& = (lngSumW& + lngW(i))
        Next i

        If (Mid(UCase(cmdLine$), 1, 6) = "PSTART") Then

            arrPuzzleSplit$ = Split(UCase(cmdLine$), Chr(32), -1)

            'For i& = 0 To (UBound(arrPuzzleSplit) - 1)

            ' arrPuzzleSplit(0), START

            lngPuzzleCreation& = arrPuzzleSplit(1)
            txtWordsearcheCreation.Text = lngPuzzleCreation&

            lngPuzzleNumber& = arrPuzzleSplit(2)
            txtWordsearches.Text = lngPuzzleNumber&

            lngPuzzleWords& = arrPuzzleSplit(3)
            txtAmount.Text = lngPuzzleWords&

            strPuzzleMatrix = arrPuzzleSplit(4)
            cmbMatrixSize.Text = strPuzzleMatrix$

            intSleep = arrPuzzleSplit(5)
            txtSleep.Text = intSleep

            'intchkHidePuzzle = arrPuzzleSplit(6)
            'chkHidePuzzle.Checked = intchkHidePuzzle

            lngPuzzleWordbank& = arrPuzzleSplit(6)
            cmbResData.SelectedIndex = lngPuzzleWordbank&

            'Next i&

        End If

        TimMultiThread.Enabled = True

        Exit Sub
ErrHld:

        'Call MsgBox("Default on load wordbank" & intLen & ".txt not found in home directory, use manual file.", vbExclamation, "Notice")


    End Sub

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        End
    End Sub

    Private Sub cmdCreatorPuzzle_Click(sender As Object, e As EventArgs) Handles cmdCreatorPuzzle.Click

        If (cmdCreatorPuzzle.Text = "Cancel") Then
            boolCancel = True
            cmdCreatorPuzzle.Text = "Creator"
            rtfPuzzle.Text = ""
            rtfPuzzleKey.Text = ""
            lngFolderTick& += 1
            Exit Sub
        End If

        If (chkOnePuzzle.Checked = True) Then

            GoTo OnePuzzleCreation

        End If

        If (MessageBox.Show("WARNING -- PUZZLE CREATION IS ABOUT TO BEGIN!", "Notice", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = vbYes) Then

            chkOnePuzzle.Checked = False
            boolOnePuzzle = False

            'Call Me.Hide
            'Call Load(frmAuto)
            'Call frmAuto.Show()

            Application.DoEvents()

            'cmdCreatorPuzzle.Enabled = False
            cmdCreatorPuzzle.Text = "Cancel"

            Call Proc_PuzzleMaker__()

            Application.DoEvents()

            Me.Text = strFormTitle$

            boolAutoClose = True

            Call frmAuto.Close()
            'Call Me.Show

            'cmdCreatorPuzzle.Enabled = True

        Else

        End If

        Exit Sub
OnePuzzleCreation:

        chkOnePuzzle.Checked = True
        boolOnePuzzle = True

        'Call Load(frmAuto)
        'Call frmAuto.Show()

        Application.DoEvents()

        cmdCreatorPuzzle.Enabled = False
        'cmdCreatorPuzzle.Text = "Cancel"

        Call Proc_PuzzleMaker__()

        lngFolderTick& += 1

        Application.DoEvents()

        Me.Text = strFormTitle$

        boolAutoClose = True

        Call frmAuto.Close()

        cmdCreatorPuzzle.Enabled = True

    End Sub

    Private Sub cmdAbout_Click(sender As Object, e As EventArgs) Handles cmdAbout.Click
        Call frmAbout.Show()
    End Sub

    Public Sub Proc_PuzzleMaker__()
        On Error Resume Next

        Dim s As Object
        Dim a As String
        Dim b As String
        Dim c As String
        Dim d As String

        Dim p As Long
        Dim m As Long
        Dim n As Long
        Dim k As Long
        Dim l As Long

        Dim i As Integer
        Dim z As Integer

        Dim dblCountWordSearch As Double

        TimMultiThread.Enabled = True

        Dim arrPathSplit() As String

        Dim strTmpPath As String

        strTmpPath$ = ""

        arrPathSplit = Split(strAppDocPath$, "\", -1)

        For i = 0 To UBound(arrPathSplit)

            strTmpPath$ = (strTmpPath$ & arrPathSplit(i) & "\")

            If (FolderExists(strTmpPath$) = False) Then

                Call MkDir(strTmpPath$)

            End If

        Next

        Dim lngChunckDoInc As Numerics.BigInteger = 0
        Dim intChuckDoTick As Integer = 0

        Dim lngChunkInc As Numerics.BigInteger = 0
        Dim lngChunkInc1 As Numerics.BigInteger = 0
        Dim lngChunkInc2 As Numerics.BigInteger = 0
        Dim lngChunkInc3 As Numerics.BigInteger = 0
        Dim lngChunkInc4 As Numerics.BigInteger = 0
        Dim lngChunkInc5 As Numerics.BigInteger = 0

        Dim intChuckTick As Integer = 0

        Dim lngChunk1 As Numerics.BigInteger = 0
        Dim lngChunk2 As Numerics.BigInteger = 0
        Dim lngChunk3 As Numerics.BigInteger = 0
        Dim lngChunk4 As Numerics.BigInteger = 0
        Dim lngChunk5 As Numerics.BigInteger = 0

        Dim intChunkTick1 As Integer = 0
        Dim intChunkTick2 As Integer = 0
        Dim intChunkTick3 As Integer = 0
        Dim intChunkTick4 As Integer = 0
        Dim intChunkTick5 As Integer = 0

        Dim strFormTagRnd As String = ""

        Do

Infinite:

            lngChunckDoInc = (txtWordsearcheCreation.Text / 10)
            lngChunkInc = (txtWordsearches.Text / 10)

            lngChunkInc1 = lngChunkInc
            lngChunkInc2 = lngChunkInc
            lngChunkInc3 = lngChunkInc
            lngChunkInc4 = lngChunkInc
            lngChunkInc5 = lngChunkInc

            If Not (lngChunckDoInc = 10) Then
                GoTo Start
            Else
                intChuckDoTick = 0
                lngFolderTick += 1
                GoTo Infinite
            End If

Start:

            If Not (intChuckTick = 10) Then
                lngDoLoopTick& = 0
                intChuckDoTick += 1
                GoTo ExecuteEx_
            Else
                intChuckTick = 0
                GoTo Start
            End If

ExecuteEx_:

            intChuckTick += 1

            Application.DoEvents()

            lngDoLoopTick& = (lngDoLoopTick& + 1)

            Call Randomize()

            strFormTagRnd$ = "wordsearch" & intLen & "_" & (CLng(Rnd() * lngRnd))

            strFormTag = "wordsearch" & intLen & "_" & lngFolderTick&

            If (FolderExists(strAppDocPath$ & "\Documents\") = False) Then
                Call MkDir(strAppDocPath$ & "\Documents\")
            End If

            If (FolderExists(strAppDocPath$ & "\Documents\Wordsearch\") = False) Then
                Call MkDir(strAppDocPath$ & "\Documents\Wordsearch\")
            End If

            If (FolderExists(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$) = False) Then
                Call MkDir(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$)
            End If

            If (FolderExists(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$) = False) Then
                Call MkDir(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$)
            End If

            For l = lngChunk1 To CLng(lngChunkInc1)

                Application.DoEvents()

                If (boolCancel = True) Then

                    strWordlist$ = ""

                    rtfPuzzle.Text = ""
                    rtfPuzzleKey.Text = ""

                    ReDim bytPuzzle(0)
                    ReDim bytPuzzleKey(0)

                    iFileNo = 0

                    boolCancel = False

                    Exit Sub

                End If

                For p = lngChunk2 To CLng(lngChunkInc2)

                    If (boolCancel = True) Then

                        strWordlist$ = ""

                        rtfPuzzle.Text = ""
                        rtfPuzzleKey.Text = ""

                        ReDim bytPuzzle(0)
                        ReDim bytPuzzleKey(0)

                        iFileNo = 0

                        boolCancel = False

                        Exit Sub

                    End If

                    For n = lngChunk3 To CLng(lngChunkInc3)

                        If (boolCancel = True) Then

                            strWordlist$ = ""

                            rtfPuzzle.Text = ""
                            rtfPuzzleKey.Text = ""

                            ReDim bytPuzzle(0)
                            ReDim bytPuzzleKey(0)

                            iFileNo = 0

                            boolCancel = False

                            Exit Sub

                        End If

                        boolFlag1 = True

                        For m = lngChunk4 To CLng(lngChunkInc4)

                            If (boolCancel = True) Then

                                strWordlist$ = ""

                                rtfPuzzle.Text = ""
                                rtfPuzzleKey.Text = ""

                                ReDim bytPuzzle(0)
                                ReDim bytPuzzleKey(0)

                                iFileNo = 0

                                boolCancel = False

                                Exit Sub

                            End If

                            'lngMTick = (lngMTick + 1)

                            For k = lngChunk5 To CLng(lngChunkInc5)

                                If (FolderExists(strAppDocPath$ & "\Documents\Wordsearch\") = False) Then
                                    Call MkDir(strAppDocPath$ & "\Documents\Wordsearch\")
                                End If

                                If (FolderExists(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$) = False) Then
                                    Call MkDir(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m)
                                End If

                                If (boolCancel = True) Then

                                    strWordlist$ = ""

                                    rtfPuzzle.Text = ""
                                    rtfPuzzleKey.Text = ""

                                    ReDim bytPuzzle(0)
                                    ReDim bytPuzzleKey(0)

                                    iFileNo = 0

                                    boolCancel = False

                                    Exit Sub

                                End If

                                If Not (txtSleep.Text = "0") Then

                                    Application.DoEvents()

                                    Call Sleep(txtSleep.Text)

                                    Application.DoEvents()

                                Else

                                    Application.DoEvents()

                                    Call Sleep(1)

                                    Application.DoEvents()

                                End If

                                ReDim arrWords(0)
                                ReDim s(0)

                                a = ""
                                b = ""
                                c$ = ""
                                d$ = ""

                                s = (Split(cmbMatrixSize.Text, "x"))
                                Call InitbytPuzzle(Val(s(0)), Val(s(1)))
                                s = (Split(rtfWords.Text, vbLf))

                                arrWords = (Split(rtfWords.Text, vbLf))

                                strWordlist$ = ""
                                Call lstSortWords.Items.Clear()

                                'rtfPuzzle.SelectionFont = CSng(txtFontSize.Text)
                                'rtfPuzzleKey.SelFontSize = 8

                                Dim j As Integer

                                For i = 1 To CLng(txtAmount.Text)

Retry:

                                    Application.DoEvents()

                                    Randomize()

                                    z = RandomInteger(0, UBound(arrWords))

                                    If AddWord(UCase(Trim(arrWords(z)))) Then

                                        'strWordlist = (strWordlist  arrWords(z)  vbCrLf)
                                        Call lstSortWords.Items.Add(arrWords(z))

                                    Else
                                        GoTo Retry
                                    End If

                                Next i

                                ' **********************************************
                                ' v3.1 Mod (None 3.0 Static Release)
                                ' **********************************************
                                With lstSortWords
                                    For z = 0 To (.Items.Count - 1)
                                        Application.DoEvents()
                                        For j = .Items.Count To (z + 1) Step -1
                                            If .Items(j) = .Items(z) Then
                                                Call .Items.Remove(j)
                                            End If
                                        Next
                                    Next
                                End With
                                ' **********************************************

                                For i = 0 To (lstSortWords.Items.Count)

                                    strWordlist$ = (strWordlist$ & lstSortWords.Items(i) & vbCrLf)

                                Next i

                                Call lstSortWords.Items.Clear()

                                Call FillRestPuzzle()
                                Call FillRestPuzzleBlank()

                                For i = 0 To UBound(bytPuzzle)
                                    If bytPuzzle(i) = 0 Then
                                        b$ = (b$ + a$ + vbCrLf)
                                        a$ = ""
                                    Else
                                        a$ = (a$ + Chr(bytPuzzle(i)) + Chr(32))
                                    End If
                                Next i

                                For i = 0 To (UBound(bytPuzzleKey))
                                    If bytPuzzleKey(i) = 0 Then
                                        d$ = (d$ + c$ + vbCrLf)
                                        c$ = ""
                                    Else
                                        c$ = (c$ + Chr(bytPuzzleKey(i)) + Chr(32))
                                    End If
                                Next i

                                rtfPuzzle.Text = (b$ + a$)
                                rtfPuzzleKey.Text = (c$ + d$)

                                a$ = ""
                                b$ = ""
                                c$ = ""
                                d$ = ""

                                Application.DoEvents()

                                'lngCountWordSearch = (lngCountWordSearch + 1)

                                dblCountWordSearch = (dblCountWordSearch + 1)

                                Me.Text = "PuzzleCard4 - Word Search Maker - [AUTOMATION- DoLoop Edition: " & lngDoLoopTick& & " ..." & Environ("HOMEPATH") & "\My Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\" & n & "\" & p & "\" & l & "\" & dblCountWordSearch & "]"  '  l  "\"  p  "\"  n  "\" 

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wordsearch.txt", rtfPuzzle.Text)

                                Using sw As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wordsearch.txt", FileMode.OpenOrCreate))
                                    sw.WriteLine(rtfPuzzle.Text)
                                    sw.Close()
                                    sw.Dispose()
                                End Using

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wl-lc.txt", (rtfPuzzle.Text  vbCrLf  strWordlist$))

                                Using sw1 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wl-lc.txt", FileMode.OpenOrCreate))
                                    sw1.WriteLine(rtfPuzzle.Text & vbCrLf & strWordlist$)
                                    sw1.Close()
                                    sw1.Dispose()
                                End Using

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wl-uc.txt", (rtfPuzzle.Text  vbCrLf  UCase(strWordlist$)))

                                Using sw2 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wl-uc.txt", FileMode.OpenOrCreate))
                                    sw2.WriteLine(rtfPuzzle.Text & vbCrLf & UCase(strWordlist$))
                                    sw2.Close()
                                    sw2.Dispose()
                                End Using

                                Application.DoEvents()

                                If (FolderExists(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m) = False) Then
                                    Call MkDir(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m)
                                End If

                                Application.DoEvents()

                                Using sw3 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wl-uc.rtf", FileMode.OpenOrCreate))
                                    sw3.WriteLine("{\rtf1\ansi\deff0\nouicompat{\fonttbl{\f0\fnil\fcharset0 Courier New;}}")
                                    sw3.WriteLine("{\*\generator Riched20 10.0.19041}\viewkind4\uc1")
                                    sw3.WriteLine("\pard\f0\fs22\lang1033\leveljc1")
                                    sw3.WriteLine(Replace(rtfPuzzle.Text, vbLf, "\par" & vbLf) & vbLf)
                                    sw3.WriteLine("\par" & vbLf & "\par")
                                    sw3.WriteLine(Replace(UCase(strWordlist$), vbLf, "\par" & vbLf))
                                    sw3.WriteLine("\par")
                                    sw3.WriteLine("}")
                                    sw3.Close()
                                    sw3.Dispose()
                                End Using

                                'rtfPuzzleSave.Text = (rtfPuzzle.Text  vbCrLf  vbCrLf  UCase(strWordlist$))
                                'rtfPuzzleSave.SelStart = 0
                                'rtfPuzzleSave.SelLength = Len(rtfPuzzleSave)
                                'rtfPuzzleSave.SelAlignment = vbCenter
                                'rtfPuzzleSave.SelFontSize = txtFontSize.Text
                                'rtfPuzzleSave.SelStart = 0
                                'Call rtfPuzzleSave.SaveFile(App.Path  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  ".rtf", rtfRTF) rtfText

                                Application.DoEvents()

                                Using sw4 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wl-uc-wk.rtf", FileMode.OpenOrCreate))
                                    sw4.WriteLine("{\rtf1\ansi\deff0\nouicompat{\fonttbl{\f0\fnil\fcharset0 Courier New;}}")
                                    sw4.WriteLine("{\*\generator Riched20 10.0.19041}\viewkind4\uc1")
                                    sw4.WriteLine("\pard\f0\fs22\lang1033\leveljc1")
                                    sw4.WriteLine(Replace(rtfPuzzle.Text, vbLf, "\par" & vbLf) & vbLf)
                                    sw4.WriteLine("\par" & vbLf & "\par")
                                    sw4.WriteLine(Replace(rtfPuzzleKey.Text, vbLf, "\par" & vbLf))
                                    sw4.WriteLine("\par")
                                    sw4.WriteLine("}")
                                    sw4.Close()
                                    sw4.Dispose()
                                End Using

                                'rtfPuzzleSave.Text = (rtfPuzzle.Text  vbCrLf  vbCrLf  rtfPuzzleKey.Text)
                                ''rtfPuzzleSave.SelStart = 0
                                'rtfPuzzleSave.SelLength = Len(rtfPuzzleSave)
                                'rtfPuzzleSave.SelAlignment = vbCenter
                                'rtfPuzzleSave.SelFontSize = txtFontSize.Text
                                'rtfPuzzleSave.SelStart = 0
                                'Call rtfPuzzleSave.SaveFile(App.Path  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wk.rtf", rtfRTF) rtfText

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wk.txt", rtfPuzzleKey.Text)

                                Using sw5 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wk.txt", FileMode.OpenOrCreate))
                                    sw5.WriteLine(rtfPuzzleKey.Text)
                                    sw5.Close()
                                    sw5.Dispose()
                                End Using

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-ws-wk.txt", (rtfPuzzle.Text  vbCrLf  rtfPuzzleKey.Text))

                                Using sw6 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-ws-wk.txt", FileMode.OpenOrCreate))
                                    sw6.WriteLine(rtfPuzzle.Text & vbCrLf & rtfPuzzleKey.Text)
                                    sw6.Close()
                                    sw6.Dispose()
                                End Using

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wl-wk.txt", (rtfPuzzleKey.Text  vbCrLf  UCase(strWordlist$)))

                                Using sw7 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wl-wk.txt", FileMode.OpenOrCreate))
                                    sw7.WriteLine(rtfPuzzleKey.Text & vbCrLf & UCase(strWordlist$))
                                    sw7.Close()
                                    sw7.Dispose()
                                End Using

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wordlist.txt", strWordlist$)

                                Using sw8 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wordlist.txt", FileMode.OpenOrCreate))
                                    sw8.WriteLine(strWordlist$)
                                    sw8.Close()
                                    sw8.Dispose()
                                End Using

                                Application.DoEvents()

                                'Call WriteFileUni(strAppDocPath$  "\Documents\Wordsearch\"  strFormTag$  "\"  m  "\ws-"  dblCountWordSearch  "-wordlist-uc.txt", UCase(strWordlist$))

                                Using sw9 As New StreamWriter(File.Open(strAppDocPath$ & "\Documents\Wordsearch\" & strFormTagRnd$ & "\" & strFormTag$ & "\" & m & "\ws-" & dblCountWordSearch & "-wordlist-uc.txt", FileMode.OpenOrCreate))
                                    sw9.WriteLine(UCase(strWordlist$))
                                    sw9.Close()
                                    sw9.Dispose()
                                End Using

                                strWordlist$ = ""

                                'rtfPuzzle.Text = ""
                                'rtfPuzzleKey.Text = ""

                                ReDim bytPuzzle(0)
                                ReDim bytPuzzleKey(0)

                                iFileNo = 0

                                If (boolOnePuzzle = True) Then

                                    Exit Do

                                    boolOnePuzzle = False

                                End If

                                lngTickClock = (lngTickClock + 1)

                            Next

                            If (k = lngChunkInc5) Then
                                lngChunkInc5 = (txtWordsearches.Text / 10)
                                lngChunk5 = 1
                            End If

                        Next

                        If (m = lngChunkInc4) Then

                            lngChunkInc4 = (txtWordsearches.Text / 10)
                            lngChunkInc4 = 1

                        End If

                    Next

                    If (n = lngChunkInc3) Then

                        lngChunkInc3 = (txtWordsearches.Text / 10)
                        lngChunkInc3 = 1

                    End If

                Next

                If (p = lngChunkInc2) Then


                    lngChunkInc2 = (txtWordsearches.Text / 10)
                    lngChunkInc2 = 1

                End If

            Next

            If (l = lngChunkInc1) Then

                lngChunkInc1 = (txtWordsearches.Text / 10)
                lngChunkInc1 = 1

            End If

            dblCountWordSearch = 0
            lngDoLoopTick = 0

            GoTo Start

        Loop

    End Sub
    Public Sub CancelEx_()

        'Call Me.Show

        boolCancel = True

    End Sub

    Private Sub TimTickClock_Tick(sender As Object, e As EventArgs) Handles TimTickClock.Tick

        lngTickclockFinal = lngTickClock
        lngTickClock = 1

    End Sub

    Private Sub TimRandomization_Tick(sender As Object, e As EventArgs) Handles TimRandomization.Tick

        Application.DoEvents()
        Call Randomize()

    End Sub

    Private Sub TimMultiThread_Tick(sender As Object, e As EventArgs) Handles TimMultiThread.Tick
        On Error GoTo ErrHld

        If (Mid(UCase(cmdLine$), 1, 6) = "PSTART") Then

            chkOnePuzzle.Checked = False
            boolOnePuzzle = False

            'Call Load(frmAuto)
            'Call frmAuto.Show()

            Application.DoEvents()

            Call Proc_PuzzleMaker__()

            Application.DoEvents()

            Me.Text = strFormTitle$

            boolAutoClose = True

            Call frmAuto.Close()

            TimMultiThread.Enabled = False

        ElseIf (Mid(UCase(cmdLine$), 1, 5) = "START") Then

            TimMultiThread.Enabled = False

        End If

        Exit Sub
ErrHld:

        Call Me.Close() : End

    End Sub

    Private Sub cmbMatrixSize_Click(sender As Object, e As EventArgs) Handles cmbMatrixSize.Click

        cmbMatrixSize.SelectionStart = 0
        cmbMatrixSize.SelectionLength = Len(cmbMatrixSize.Text)

    End Sub

    Private Sub cmbMatrixSize_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMatrixSize.SelectedIndexChanged

        cmbMatrixSize.Text = LCase(cmbMatrixSize.Text)

        If (InStr(1, cmbMatrixSize.Text, "x", vbBinaryCompare) <> 0) Then
        Else

            cmbMatrixSize.Text = "26x26"

        End If

    End Sub

    Private Sub txtFontSize_TextChanged(sender As Object, e As EventArgs) Handles txtFontSize.TextChanged

        If (IsNumeric(txtFontSize.Text) = True) Then
        Else

            txtFontSize.Text = "12"

        End If

    End Sub

    Private Sub chkBold_CheckedChanged(sender As Object, e As EventArgs) Handles chkBold.CheckedChanged

        If (chkBold.Enabled = True) Then

            boolFontBold = False

            chkBold.Enabled = False

        ElseIf (chkBold.Enabled = False) Then

            boolFontBold = True

            chkBold.Enabled = True

        End If

    End Sub

    Private Sub chkHidePuzzle_CheckedChanged(sender As Object, e As EventArgs) Handles chkHidePuzzle.CheckedChanged

        'Call Form_Resize

    End Sub

    Private Sub chkOnePuzzle_CheckedChanged(sender As Object, e As EventArgs) Handles chkOnePuzzle.CheckedChanged

        If (chkOnePuzzle.Checked = False) Then

            boolOnePuzzle = False

        ElseIf (chkOnePuzzle.Checked = True) Then

            boolOnePuzzle = True

        End If

    End Sub

    Private Sub cmbResData_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbResData.SelectedIndexChanged
        On Error Resume Next

        Dim sRTFText As String

        Select Case cmbResData.SelectedItem

            Case "100" : sRTFText$ = My.Resources.wordbank
            Case "101" : sRTFText$ = My.Resources.wordbank0
            Case "102" : sRTFText$ = My.Resources.wordbank1
            Case "103" : sRTFText$ = My.Resources.wordbank2
            Case "104" : sRTFText$ = My.Resources.wordbank3
            Case "105" : sRTFText$ = My.Resources.wordbank4
            Case "106" : sRTFText$ = My.Resources.wordbank5
            Case "107" : sRTFText$ = My.Resources.wordbank6
            Case "108" : sRTFText$ = My.Resources.wordbank7
            Case "109" : sRTFText$ = My.Resources.wordbank8
            Case "110" : sRTFText$ = My.Resources.wordbank9
            Case "111" : sRTFText$ = My.Resources.wordbank10
            Case "112" : sRTFText$ = My.Resources.wordbank11
            Case "113" : sRTFText$ = My.Resources.wordbank12
            Case "114" : sRTFText$ = My.Resources.wordbank13
            Case "115" : sRTFText$ = My.Resources.wordbank14
            Case "116" : sRTFText$ = My.Resources.wordbank15
            Case Else : sRTFText$ = My.Resources.wordbank

        End Select

        ReDim arrWords(0)

        arrWords = Split(sRTFText$, vbCrLf, -1)

        rtfWords.Text = sRTFText$

    End Sub
    Public Shared Function ExtractResource(filename As [String]) As Byte()
        Dim a As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly()
        Using resFilestream As IO.Stream = a.GetManifestResourceStream(filename)
            If resFilestream Is Nothing Then
                Return Nothing
            End If
            Dim ba As Byte() = New Byte(resFilestream.Length - 1) {}
            resFilestream.Read(ba, 0, ba.Length)
            Return ba
        End Using
    End Function

    Private Sub txtAmount_Click(sender As Object, e As EventArgs) Handles txtAmount.Click

        txtAmount.SelectionStart = 0
        txtAmount.SelectionLength = Len(txtAmount.Text)

    End Sub

    Private Sub txtAmount_TextChanged(sender As Object, e As EventArgs) Handles txtAmount.TextChanged

        If (IsNumeric(txtAmount.Text) = True) Then
        Else

            txtFontSize.Text = "24"

        End If

    End Sub

    Private Sub txtSleep_Click(sender As Object, e As EventArgs) Handles txtSleep.Click

        txtSleep.SelectionStart = 0
        txtSleep.SelectionLength = Len(txtSleep.Text)

    End Sub

    Private Sub txtSleep_TextChanged(sender As Object, e As EventArgs) Handles txtSleep.TextChanged

        If (IsNumeric(txtSleep.Text) = False) Then
            txtSleep.Text = "5"
        Else
            If (txtSleep.Text >= "5001") Then
                txtSleep.Text = "1000"
            End If
        End If

    End Sub

    Private Sub txtWordsearcheCreation_Layout(sender As Object, e As LayoutEventArgs) Handles txtWordsearcheCreation.Layout

        txtWordsearcheCreation.SelectionStart = 0
        txtWordsearcheCreation.SelectionLength = Len(txtWordsearcheCreation.Text)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtWordsearcheCreation.TextChanged

        If (IsNumeric(txtWordsearches.Text) = True) Then
        Else

            txtWordsearches.Text = "20"

        End If

    End Sub

    Private Sub txtWordsearches_Click(sender As Object, e As EventArgs) Handles txtWordsearches.Click

        txtWordsearches.SelectionStart = 0
        txtWordsearches.SelectionLength = Len(txtWordsearches.Text)

    End Sub

    Private Sub txtWordsearches_TextChanged(sender As Object, e As EventArgs) Handles txtWordsearches.TextChanged

        If (IsNumeric(txtWordsearches.Text) = True) Then
        Else

            txtWordsearches.Text = "20"

        End If

    End Sub

    Private Sub cmdSwap_Click(sender As Object, e As EventArgs) Handles cmdSwap.Click

        If (cmdSwap.Text = "PuzzleKey") Then

            cmdSwap.Text = "Puzzle"

            rtfPuzzle.Visible = False
            rtfPuzzleKey.Visible = True

        ElseIf (cmdSwap.Text = "Puzzle") Then

            cmdSwap.Text = "PuzzleKey"

            rtfPuzzleKey.Visible = False
            rtfPuzzle.Visible = True

        End If

    End Sub

    Public Sub RunLoadWordbank()

        rtfWords.Enabled = False

        Dim appPath As String = Application.StartupPath()

        'Dim reader As IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(appPath$ & "\wordbank0.txt")
        'Dim a As String

        'Do
        '    Application.DoEvents()
        '    a$ = reader.ReadLine
        '    txtWords.Text &= a$.Trim & vbCrLf
        '    Application.DoEvents()
        'Loop Until a Is Nothing

        'Call reader.Close()

        Call rtfWords.LoadFile(appPath$ & "\wordbank0.txt", RichTextBoxStreamType.PlainText)

        ReDim arrWords(0)

        arrWords = Split(rtfWords.Text, vbLf, -1)

        rtfWords.Enabled = True

    End Sub

    Private Sub TimLoadWordbank_Tick(sender As Object, e As EventArgs) Handles TimLoadWordbank.Tick
        Call RunLoadWordbank() : TimLoadWordbank.Enabled = False
    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        boolCancel = True
        cmdCreatorPuzzle.Text = "Creator"
        rtfPuzzle.Text = ""
        rtfPuzzleKey.Text = ""
        lngFolderTick& += 1

        Call Me.Close()
        End

    End Sub

End Class
