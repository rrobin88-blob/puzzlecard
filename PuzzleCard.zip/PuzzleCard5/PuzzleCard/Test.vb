﻿Option Explicit On
Option Strict On

Public Class Test

    Private Sub btCheck_Click(sender As Object, e As EventArgs) Handles btCheck.Click

        If (UCase(txtJesus.Text) = "JESUS") Or (UCase(txtJesus.Text) = "CHRIST") Or
            (UCase(txtJesus.Text) = "JESUS CHRIST") Or (UCase(txtJesus.Text) = "CHRIST JESUS") Or
            (UCase(txtJesus.Text) = "JESUSCHRIST") Or (UCase(txtJesus.Text) = "CHRISTJESUS") Then

            boolTestPassed = True

            txtJesus.Text = ""

            Call Me.Close()

        End If

    End Sub

    Private Sub btClose_Click(sender As Object, e As EventArgs) Handles btClose.Click

        boolTestPassed = False

        Call Me.Close()

    End Sub

End Class