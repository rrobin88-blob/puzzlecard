﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAuto
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TimTick = New System.Windows.Forms.Timer(Me.components)
        Me.lblInProc = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(110, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(213, 40)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "AUTOMATION"
        '
        'TimTick
        '
        Me.TimTick.Interval = 1000
        '
        'lblInProc
        '
        Me.lblInProc.AutoSize = True
        Me.lblInProc.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblInProc.ForeColor = System.Drawing.Color.Green
        Me.lblInProc.Location = New System.Drawing.Point(158, 82)
        Me.lblInProc.Name = "lblInProc"
        Me.lblInProc.Size = New System.Drawing.Size(116, 21)
        Me.lblInProc.TabIndex = 1
        Me.lblInProc.Text = "IN PROGRESS."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(159, 136)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Press [Enter] to exit."
        Me.Label3.Visible = False
        '
        'frmAuto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(439, 179)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblInProc)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAuto"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Puzzle of all PuzzleMakers."
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TimTick As Timer
    Friend WithEvents lblInProc As Label
    Friend WithEvents Label3 As Label
End Class
