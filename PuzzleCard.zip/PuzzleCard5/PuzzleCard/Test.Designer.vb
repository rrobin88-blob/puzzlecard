﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Test
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblJesus = New System.Windows.Forms.Label()
        Me.txtJesus = New System.Windows.Forms.TextBox()
        Me.btClose = New System.Windows.Forms.Button()
        Me.btCheck = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblJesus
        '
        Me.lblJesus.AutoSize = True
        Me.lblJesus.Location = New System.Drawing.Point(12, 17)
        Me.lblJesus.Name = "lblJesus"
        Me.lblJesus.Size = New System.Drawing.Size(209, 15)
        Me.lblJesus.TabIndex = 0
        Me.lblJesus.Text = "What is Jesus' Name in the Holy Bible?"
        '
        'txtJesus
        '
        Me.txtJesus.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.txtJesus.Location = New System.Drawing.Point(12, 35)
        Me.txtJesus.Name = "txtJesus"
        Me.txtJesus.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtJesus.Size = New System.Drawing.Size(357, 25)
        Me.txtJesus.TabIndex = 0
        '
        'btClose
        '
        Me.btClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btClose.Location = New System.Drawing.Point(294, 84)
        Me.btClose.Name = "btClose"
        Me.btClose.Size = New System.Drawing.Size(75, 23)
        Me.btClose.TabIndex = 2
        Me.btClose.Text = "Close"
        Me.btClose.UseVisualStyleBackColor = True
        '
        'btCheck
        '
        Me.btCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btCheck.Location = New System.Drawing.Point(12, 84)
        Me.btCheck.Name = "btCheck"
        Me.btCheck.Size = New System.Drawing.Size(75, 23)
        Me.btCheck.TabIndex = 1
        Me.btCheck.Text = "Check"
        Me.btCheck.UseVisualStyleBackColor = True
        '
        'Test
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(381, 119)
        Me.Controls.Add(Me.btCheck)
        Me.Controls.Add(Me.btClose)
        Me.Controls.Add(Me.txtJesus)
        Me.Controls.Add(Me.lblJesus)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Test"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Test Question"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblJesus As Label
    Friend WithEvents txtJesus As TextBox
    Friend WithEvents btClose As Button
    Friend WithEvents btCheck As Button
End Class
