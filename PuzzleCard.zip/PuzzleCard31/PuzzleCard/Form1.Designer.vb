﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.rtfPuzzle = New System.Windows.Forms.RichTextBox()
        Me.TimRandomization = New System.Windows.Forms.Timer(Me.components)
        Me.TimMultiThread = New System.Windows.Forms.Timer(Me.components)
        Me.rtfPuzzleSave = New System.Windows.Forms.RichTextBox()
        Me.rtfPuzzleKey = New System.Windows.Forms.RichTextBox()
        Me.lstSortWords = New System.Windows.Forms.ListBox()
        Me.cmdSwap = New System.Windows.Forms.Button()
        Me.cmdAbout = New System.Windows.Forms.Button()
        Me.cmdCreatorPuzzle = New System.Windows.Forms.Button()
        Me.TimTickClock = New System.Windows.Forms.Timer(Me.components)
        Me.chkBold = New System.Windows.Forms.CheckBox()
        Me.txtFontSize = New System.Windows.Forms.TextBox()
        Me.rtfWords = New System.Windows.Forms.RichTextBox()
        Me.chkHidePuzzle = New System.Windows.Forms.CheckBox()
        Me.chkOnePuzzle = New System.Windows.Forms.CheckBox()
        Me.cmbResData = New System.Windows.Forms.ComboBox()
        Me.cmbMatrixSize = New System.Windows.Forms.ComboBox()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.txtWordsearches = New System.Windows.Forms.TextBox()
        Me.txtSleep = New System.Windows.Forms.TextBox()
        Me.txtWordsearcheCreation = New System.Windows.Forms.TextBox()
        Me.TimLoadWordbank = New System.Windows.Forms.Timer(Me.components)
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'rtfPuzzle
        '
        Me.rtfPuzzle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtfPuzzle.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.rtfPuzzle.Location = New System.Drawing.Point(301, 47)
        Me.rtfPuzzle.Name = "rtfPuzzle"
        Me.rtfPuzzle.Size = New System.Drawing.Size(777, 437)
        Me.rtfPuzzle.TabIndex = 35
        Me.rtfPuzzle.Text = ""
        '
        'TimRandomization
        '
        Me.TimRandomization.Interval = 1
        '
        'TimMultiThread
        '
        Me.TimMultiThread.Interval = 10000
        '
        'rtfPuzzleSave
        '
        Me.rtfPuzzleSave.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.rtfPuzzleSave.Location = New System.Drawing.Point(149, 216)
        Me.rtfPuzzleSave.Name = "rtfPuzzleSave"
        Me.rtfPuzzleSave.Size = New System.Drawing.Size(131, 96)
        Me.rtfPuzzleSave.TabIndex = 34
        Me.rtfPuzzleSave.Text = ""
        Me.rtfPuzzleSave.Visible = False
        '
        'rtfPuzzleKey
        '
        Me.rtfPuzzleKey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtfPuzzleKey.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.rtfPuzzleKey.Location = New System.Drawing.Point(301, 47)
        Me.rtfPuzzleKey.Name = "rtfPuzzleKey"
        Me.rtfPuzzleKey.Size = New System.Drawing.Size(777, 437)
        Me.rtfPuzzleKey.TabIndex = 33
        Me.rtfPuzzleKey.Text = ""
        Me.rtfPuzzleKey.Visible = False
        '
        'lstSortWords
        '
        Me.lstSortWords.FormattingEnabled = True
        Me.lstSortWords.ItemHeight = 15
        Me.lstSortWords.Location = New System.Drawing.Point(22, 216)
        Me.lstSortWords.Name = "lstSortWords"
        Me.lstSortWords.Size = New System.Drawing.Size(120, 94)
        Me.lstSortWords.TabIndex = 32
        Me.lstSortWords.Visible = False
        '
        'cmdSwap
        '
        Me.cmdSwap.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSwap.Location = New System.Drawing.Point(301, 8)
        Me.cmdSwap.Name = "cmdSwap"
        Me.cmdSwap.Size = New System.Drawing.Size(109, 33)
        Me.cmdSwap.TabIndex = 31
        Me.cmdSwap.Text = "PuzzleKey"
        Me.cmdSwap.UseVisualStyleBackColor = True
        '
        'cmdAbout
        '
        Me.cmdAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAbout.Location = New System.Drawing.Point(189, 120)
        Me.cmdAbout.Name = "cmdAbout"
        Me.cmdAbout.Size = New System.Drawing.Size(106, 23)
        Me.cmdAbout.TabIndex = 30
        Me.cmdAbout.Text = "About"
        Me.cmdAbout.UseVisualStyleBackColor = True
        '
        'cmdCreatorPuzzle
        '
        Me.cmdCreatorPuzzle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCreatorPuzzle.Location = New System.Drawing.Point(189, 8)
        Me.cmdCreatorPuzzle.Name = "cmdCreatorPuzzle"
        Me.cmdCreatorPuzzle.Size = New System.Drawing.Size(106, 66)
        Me.cmdCreatorPuzzle.TabIndex = 29
        Me.cmdCreatorPuzzle.Text = "Creator"
        Me.cmdCreatorPuzzle.UseVisualStyleBackColor = True
        '
        'TimTickClock
        '
        Me.TimTickClock.Interval = 1000
        '
        'chkBold
        '
        Me.chkBold.AutoSize = True
        Me.chkBold.Location = New System.Drawing.Point(22, 191)
        Me.chkBold.Name = "chkBold"
        Me.chkBold.Size = New System.Drawing.Size(50, 19)
        Me.chkBold.TabIndex = 28
        Me.chkBold.Text = "Bold"
        Me.chkBold.UseVisualStyleBackColor = True
        Me.chkBold.Visible = False
        '
        'txtFontSize
        '
        Me.txtFontSize.Location = New System.Drawing.Point(22, 162)
        Me.txtFontSize.Name = "txtFontSize"
        Me.txtFontSize.Size = New System.Drawing.Size(35, 23)
        Me.txtFontSize.TabIndex = 27
        Me.txtFontSize.Text = "12"
        Me.txtFontSize.Visible = False
        '
        'rtfWords
        '
        Me.rtfWords.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.rtfWords.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.rtfWords.Location = New System.Drawing.Point(11, 149)
        Me.rtfWords.Name = "rtfWords"
        Me.rtfWords.Size = New System.Drawing.Size(284, 335)
        Me.rtfWords.TabIndex = 26
        Me.rtfWords.Text = ""
        '
        'chkHidePuzzle
        '
        Me.chkHidePuzzle.AutoSize = True
        Me.chkHidePuzzle.Location = New System.Drawing.Point(63, 162)
        Me.chkHidePuzzle.Name = "chkHidePuzzle"
        Me.chkHidePuzzle.Size = New System.Drawing.Size(87, 19)
        Me.chkHidePuzzle.TabIndex = 25
        Me.chkHidePuzzle.Text = "Hide Puzzle"
        Me.chkHidePuzzle.UseVisualStyleBackColor = True
        Me.chkHidePuzzle.Visible = False
        '
        'chkOnePuzzle
        '
        Me.chkOnePuzzle.AutoSize = True
        Me.chkOnePuzzle.Location = New System.Drawing.Point(11, 95)
        Me.chkOnePuzzle.Name = "chkOnePuzzle"
        Me.chkOnePuzzle.Size = New System.Drawing.Size(132, 19)
        Me.chkOnePuzzle.TabIndex = 24
        Me.chkOnePuzzle.Text = "One Puzzle Creation"
        Me.chkOnePuzzle.UseVisualStyleBackColor = True
        '
        'cmbResData
        '
        Me.cmbResData.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbResData.FormattingEnabled = True
        Me.cmbResData.Location = New System.Drawing.Point(12, 66)
        Me.cmbResData.Name = "cmbResData"
        Me.cmbResData.Size = New System.Drawing.Size(83, 23)
        Me.cmbResData.TabIndex = 23
        '
        'cmbMatrixSize
        '
        Me.cmbMatrixSize.FormattingEnabled = True
        Me.cmbMatrixSize.Location = New System.Drawing.Point(101, 8)
        Me.cmbMatrixSize.Name = "cmbMatrixSize"
        Me.cmbMatrixSize.Size = New System.Drawing.Size(83, 23)
        Me.cmbMatrixSize.TabIndex = 22
        Me.cmbMatrixSize.Tag = "Matrix"
        Me.cmbMatrixSize.Text = "26x26"
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(11, 37)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(83, 23)
        Me.txtAmount.TabIndex = 21
        Me.txtAmount.Tag = "Words"
        Me.txtAmount.Text = "24"
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWordsearches
        '
        Me.txtWordsearches.Location = New System.Drawing.Point(12, 8)
        Me.txtWordsearches.Name = "txtWordsearches"
        Me.txtWordsearches.Size = New System.Drawing.Size(83, 23)
        Me.txtWordsearches.TabIndex = 20
        Me.txtWordsearches.Tag = "Wordsearches"
        Me.txtWordsearches.Text = "83010348331692982263"
        Me.txtWordsearches.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSleep
        '
        Me.txtSleep.Location = New System.Drawing.Point(100, 37)
        Me.txtSleep.Name = "txtSleep"
        Me.txtSleep.Size = New System.Drawing.Size(83, 23)
        Me.txtSleep.TabIndex = 19
        Me.txtSleep.Tag = "Sleep Timer"
        Me.txtSleep.Text = "5"
        Me.txtSleep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWordsearcheCreation
        '
        Me.txtWordsearcheCreation.Location = New System.Drawing.Point(11, 8)
        Me.txtWordsearcheCreation.Name = "txtWordsearcheCreation"
        Me.txtWordsearcheCreation.Size = New System.Drawing.Size(83, 23)
        Me.txtWordsearcheCreation.TabIndex = 18
        Me.txtWordsearcheCreation.Tag = "Do Loop"
        Me.txtWordsearcheCreation.Text = "83010348331692982263"
        Me.txtWordsearcheCreation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtWordsearcheCreation.Visible = False
        '
        'TimLoadWordbank
        '
        Me.TimLoadWordbank.Interval = 500
        '
        'cmdClose
        '
        Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdClose.Location = New System.Drawing.Point(189, 80)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(106, 34)
        Me.cmdClose.TabIndex = 36
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1087, 496)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.rtfPuzzleSave)
        Me.Controls.Add(Me.lstSortWords)
        Me.Controls.Add(Me.cmdSwap)
        Me.Controls.Add(Me.cmdAbout)
        Me.Controls.Add(Me.cmdCreatorPuzzle)
        Me.Controls.Add(Me.chkBold)
        Me.Controls.Add(Me.txtFontSize)
        Me.Controls.Add(Me.chkHidePuzzle)
        Me.Controls.Add(Me.chkOnePuzzle)
        Me.Controls.Add(Me.cmbResData)
        Me.Controls.Add(Me.cmbMatrixSize)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.txtWordsearches)
        Me.Controls.Add(Me.txtSleep)
        Me.Controls.Add(Me.txtWordsearcheCreation)
        Me.Controls.Add(Me.rtfPuzzle)
        Me.Controls.Add(Me.rtfPuzzleKey)
        Me.Controls.Add(Me.rtfWords)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PuzzleCard"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rtfPuzzle As RichTextBox
    Friend WithEvents TimRandomization As Timer
    Friend WithEvents TimMultiThread As Timer
    Friend WithEvents rtfPuzzleSave As RichTextBox
    Friend WithEvents rtfPuzzleKey As RichTextBox
    Friend WithEvents lstSortWords As ListBox
    Friend WithEvents cmdSwap As Button
    Friend WithEvents cmdAbout As Button
    Friend WithEvents cmdCreatorPuzzle As Button
    Friend WithEvents TimTickClock As Timer
    Friend WithEvents chkBold As CheckBox
    Friend WithEvents txtFontSize As TextBox
    Friend WithEvents rtfWords As RichTextBox
    Friend WithEvents chkHidePuzzle As CheckBox
    Friend WithEvents chkOnePuzzle As CheckBox
    Friend WithEvents cmbResData As ComboBox
    Friend WithEvents cmbMatrixSize As ComboBox
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents txtWordsearches As TextBox
    Friend WithEvents txtSleep As TextBox
    Friend WithEvents txtWordsearcheCreation As TextBox
    Friend WithEvents TimLoadWordbank As Timer
    Friend WithEvents cmdClose As Button
End Class
