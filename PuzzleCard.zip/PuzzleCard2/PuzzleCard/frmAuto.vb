﻿Public Class frmAuto
    Private Sub frmAuto_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        TimTick.Enabled = True

        Call SetTopMostWindow(Me.Handle, True)

    End Sub

    Private Sub frmAuto_Leave(sender As Object, e As EventArgs) Handles Me.Leave

        Call SetTopMostWindow(Me.Handle, False)

    End Sub

    Private Sub TimTick_Tick(sender As Object, e As EventArgs) Handles TimTick.Tick

        Select Case (lblInProc.Text)

            Case "IN PROGRESS." : lblInProc.Text = "IN PROGRESS.."
            Case "IN PROGRESS.." : lblInProc.Text = "IN PROGRESS..."
            Case "IN PROGRESS..." : lblInProc.Text = "IN PROGRESS...."
            Case "IN PROGRESS...." : lblInProc.Text = "IN PROGRESS....."
            Case "IN PROGRESS....." : lblInProc.Text = "IN PROGRESS."

        End Select

    End Sub

    Private Sub frmAuto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress

        If (e.KeyChar = Convert.ToChar(Keys.Enter)) Or (e.KeyChar = Convert.ToChar(Keys.Space)) Or (e.KeyChar = Convert.ToChar(Keys.Escape)) Then

            Call Form1.CancelEx_()
            Call Me.Close()

        End If

    End Sub

End Class