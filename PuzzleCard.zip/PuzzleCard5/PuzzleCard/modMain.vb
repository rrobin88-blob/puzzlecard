﻿Option Explicit On

Module modMain

    Public lngTickClock As Long
    Public lngTickclockFinal As Long

    Public boolAutoClose As Boolean

    Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

    Public boolCancel As Boolean

    Public intIcon As Integer

    Public boolTestPassed As Boolean = False

    Public Function RandomInteger(Lowerbound As Integer, Upperbound As Integer) As Integer
        RandomInteger = Int((Upperbound - Lowerbound + 1) * Rnd() + Lowerbound)
    End Function

    Public Function FolderExists(sFullPath As String) As Boolean

        If (IO.Directory.Exists(sFullPath) = True) Then
            Return True
        Else
            Return False
        End If

    End Function

End Module
