﻿Public Class frmAbout
    Private Sub btClose_Click(sender As Object, e As EventArgs) Handles btClose.Click
        Call Me.Close()
    End Sub

End Class