﻿Option Explicit On
Option Strict On

Module modPuzzle

    Public bytPuzzle() As Byte
    Public bytPuzzleKey() As Byte

    Public lngPos() As Integer
    Public lngDir(7) As Integer

    Public lngW(25) As Integer ' 25
    Public lngSumW As Integer
    Public Sub InitbytPuzzle(ByVal w As Integer, ByVal h As Integer)

        Dim i As Integer

        Dim j As Integer
        Dim k As Integer

        Dim sz As Integer

        sz = (w + 1) * h

        ReDim bytPuzzle(sz - 1)
        ReDim bytPuzzleKey(sz - 1)

        For i = 0 To (sz - 1)
            bytPuzzle(i) = 32
            bytPuzzleKey(i) = 32
        Next i

        For i = w To (sz - 1) Step (w + 1)
            bytPuzzle(i) = 0 'prevents breaking on edges
            bytPuzzleKey(i) = 0
        Next i

        lngDir(0) = -w - 1 'up
        lngDir(1) = -w 'upright
        lngDir(2) = 1 'right
        lngDir(3) = w + 2 'downright
        lngDir(4) = w + 1 'down
        lngDir(5) = w 'downleft
        lngDir(6) = -1 'left
        lngDir(7) = -w - 2 'upleft

        ReDim lngPos(w * h - 1)

        For i = 0 To (sz - 1)

            'insert lngPos in random order
            If (bytPuzzle(i) = 32) Or (bytPuzzleKey(i) = 32) Then

                k = (CInt(Rnd() * (j + 1)))

                lngPos(j) = (lngPos(k))
                lngPos(k) = (i)

                j = (j + 1)

            End If

        Next i

    End Sub

    Public Function AddWord(ByVal s As String) As Boolean

        Dim x As Integer
        Dim d As Integer
        Dim p As Integer
        Dim a As Integer
        Dim dc As Integer

        If Len(s) = 0 Then

            AddWord = True

            Exit Function

        End If

        dc = CInt(Rnd() * 2) ' 8

        For p = 0 To UBound(lngPos)

            x = lngPos(p)

            For d = 0 To UBound(lngDir)

                a = lngDir(d Xor dc)

                If (FitPuzzle(s$, x, a) = True) Then

                    Call PlacePuzzlePiece(s$, x, a)

                    AddWord = True

                    Exit Function

                End If

            Next d

        Next p

        AddWord = False

    End Function

    Public Function FitPuzzle(s As String, ByVal x As Integer, ByVal a As Integer) As Boolean

        Dim i As Integer
        Dim c As Integer

        For i = 1 To Len(s$)

            c = Asc(Mid(s$, i, 1))

            If (x < 0) Or
            (x > UBound(bytPuzzle)) Or
            (x > UBound(bytPuzzleKey)) Then

                FitPuzzle = False

                Exit Function

            End If

            If (bytPuzzle(x) <> 32) And
           (bytPuzzleKey(x) <> 32) And
           (bytPuzzle(x) <> c) Then

                FitPuzzle = False

                Exit Function

            End If

            x = (x + a)

        Next i

        FitPuzzle = True

    End Function

    Public Sub PlacePuzzlePiece(ByVal s As String, ByVal x As Integer, ByVal a As Integer)

        Dim i As Integer

        For i = 1 To Len(s$)

            bytPuzzle(x) = CByte(Asc(Mid(s$, i, 1)))
            bytPuzzleKey(x) = CByte(Asc(Mid(s$, i, 1)))

            x = (x + a)

        Next i

    End Sub

    Public Sub FillRestPuzzle()

        Dim i As Integer

        For i = 0 To UBound(bytPuzzle)
            If (bytPuzzle(i) = 32) Then bytPuzzle(i) = RandomLetter()
        Next i

    End Sub

    Public Sub FillRestPuzzleBlank()

        Dim i As Integer

        For i = 0 To UBound(bytPuzzleKey)
            If bytPuzzleKey(i) = 32 Then bytPuzzleKey(i) = 32
        Next i

    End Sub

    Public Function RandomLetter() As Byte

        'Dim i As Integer
        'Dim c As Integer

        'c = CInt(Rnd() * lngSumW)

        'Do
        'c = (c - lngW(i))
        'If (c < 0) Then Exit Do
        'i = (i + 1)
        'Loop

        Call Randomize()

        Return CByte(Int(65 + (Rnd() * 25))) 'CByte(Int(65 + (Rnd() * i)))

    End Function

End Module
